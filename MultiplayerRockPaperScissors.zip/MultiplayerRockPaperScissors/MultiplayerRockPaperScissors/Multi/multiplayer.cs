﻿using System;
namespace MultiplayerRockPaperScissors.Multi
{
	public class multiplayer
	{
		

        public void Run()
		{
			


			//initialize the variable 
			Random random = new Random();
			bool PlayAgain = true;
			int player1;
			int player2;
			int win1=0;
			int lost1=0;
			int draw1=0;

			int win2=0;
			int lost2=0;
			int draw2=0;

			//asking for the names of the participants 
			Console.WriteLine("Enter Your Name Player 1");
			string name1 = Console.ReadLine();

			Console.WriteLine("Enter Your Name Player 2");
			string name2 = Console.ReadLine();

			
			
			//informs the participants about the rules 
			Console.WriteLine("The rules are simple before the game starts \n each player will be shown 3 options to insert number that which will correspond to the move you will play e.g. the number 1 might be rock and the number 2 might be paper \n each player will" +
				" have different numbers linked to their moves so your paper wont be the same number as the next player...if you understand the rules type (start)");
			string response = Console.ReadLine();
			response = response.ToUpper();

			if(response != "START")
			{
				Console.WriteLine("Invalid input enter (START) to procede");
				response = Console.ReadLine();
				response.ToUpper();
			}


            Console.WriteLine($" {name1} options is about to be displayed so {name2} needs to turn around and look away \n Enter (ready) once {name2} looks away");
            string response2 = Console.ReadLine();
            response2 = response2.ToUpper();

            if (response2 != "READY")
            {
                Console.WriteLine("Invalid input...Enter (ready)");
            }

			//entering the numbers for the moves 
			Console.WriteLine("Enter what number you wish to allocate to (Rock)");
			 int Rock1 = Convert.ToInt32(Console.ReadLine());
			

			Console.WriteLine("Enter what number you wish to allocate to (Paper)");
			int Paper1 = Convert.ToInt32(Console.ReadLine());

			Console.WriteLine("Enter what number you wish to allocate to (Scissors)");
			int Scissors1 = Convert.ToInt32(Console.ReadLine());

			Console.Clear();



			Console.WriteLine($"{name2} can now turn around ...{name1} should now turn away so that  can fill in his options");



            Console.WriteLine("Enter what number you wish to allocate to (Rock)");
            int Rock2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter what number you wish to allocate to (Paper)");
            int Paper2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter what number you wish to allocate to (Scissors)");
            int Scissors2 = Convert.ToInt32(Console.ReadLine());

			Console.Clear();

			Console.WriteLine($"{name1} can now turn around and the game can start");

			//keeps looping the game
            while (PlayAgain)
			{
                player1 = 0;
                player1 = 0;

				Console.WriteLine($"{name1} please enter the number for your move");
				 int move1 = Convert.ToInt32(Console.ReadLine());

				if(move1!=Rock1 && move1!=Paper1 && move1 != Scissors1)
				{
					Console.WriteLine("Invalid input...Enter correct number for your move!!!");
                    move1 = Convert.ToInt32(Console.ReadLine());
                }
				Console.Clear();
				Console.WriteLine($"{name2} please enter the number for your move");
				int move2 = Convert.ToInt32(Console.ReadLine());

                if (move2 != Rock2 && move2 != Paper2 && move2 != Scissors2)
                {
                    Console.WriteLine("Invalid input...Enter correct number for your move!!!");
                    move2 = Convert.ToInt32(Console.ReadLine());
                }

				Console.Clear();
				

				//runs through the options the partcipants chose and determines the winner
				if (move1 == Rock1)
				{
					if (move2== Rock2)
					{
						Console.WriteLine($"{name1} throws ROCK \n {name2} throws ROCK");
						Console.WriteLine("Its a draw");
						draw1++;
						draw2++;
					}
					else if(move2 == Paper2)
					{
                        Console.WriteLine($"{name1} throws ROCK \n {name2} throws PAPER");
                        Console.WriteLine($"{name2} wins");
						lost1++;
						win2++;
					}
					else
					{
                        Console.WriteLine($"{name1} throws ROCK \n {name2} throws SCISSORS");
                        Console.WriteLine($"{name1} wins");
						win1++;
						lost2++;
					}
				}
				else if (move1 == Paper1)
				{
					if(move2 == Rock2)
					{
                        Console.WriteLine($"{name1} throws PAPER \n {name2} throws ROCK");
                        Console.WriteLine($"{name1} wins");
						win1++;
						lost2++;
					}
					else if(move2 == Paper2)
					{
                        Console.WriteLine($"{name1} throws PAPER \n {name2} throws PAPER");
                        Console.WriteLine("Its a Draw");
						draw1++;
						draw2++;
					}
					else
					{
                        Console.WriteLine($"{name1} throws PAPER \n {name2} throws SCISSORS");
                        Console.WriteLine($"{name2} wins");
						lost1++;
						win2++;
					}
				}
				else
				{
					if (move2==Rock2)
					{
                        Console.WriteLine($"{name1} throws SCISSORS \n {name2} throws ROCK");
                        Console.WriteLine($"{name2} wins");
						lost1++;
						win2++;
					}
					else if (move2==Paper2)
					{
                        Console.WriteLine($"{name1} throws SCISSORS \n {name2} throws PAPER");
                        Console.WriteLine($"{name1} wins");
						win1++;
						lost2++;
					}

					else
					{
                        Console.WriteLine($"{name1} throws SCISSORS \n {name2} throws SCISSORS");
                        Console.WriteLine($"Its a Draw");
						draw1++;
						draw2++;
					}
				}

				//indicates the scores of the participants 

                Console.WriteLine($"{name1}: Won: {win1} Draws: {draw1} lost: {lost1}");
				Console.WriteLine($"{name2}: Won: {win2} Draws: {draw2} lost: {lost2}");


            }

			
			
		}
	

	}
}

