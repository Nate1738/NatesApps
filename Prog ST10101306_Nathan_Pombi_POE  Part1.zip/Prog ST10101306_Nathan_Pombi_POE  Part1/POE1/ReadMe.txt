 
 
Explanation:
This console application prompts the user to enter the recipe details, displays the recipe, scales it by a factor, resets it, clears it, and displays it again after each operation. 
The recipe is not persisted between runs, so the user can enter a new recipe each time the application is run.
 
In depth:
 
This solution uses object-oriented programming concepts to create a Recipe class that represents a recipe. The Recipe class contains methods for adding ingredients and steps, scaling the recipe by a factor, resetting the quantities of the ingredients, clearing the recipe, and displaying the recipe in a formatted string. 
 
 
The class uses two other classes, Ingredient and Step, to represent the individual components of the recipe.
The console application prompts the user to enter the details of the recipe, creates a Recipe object, and calls its methods to manipulate the recipe as per the user's request. 
The application takes user input using the Console.ReadLine() method and converts it to the appropriate data type using the Int32.TryParse(), double.Parse(), or string methods.
 
When the user requests to scale the recipe, the Scale() method in the Recipe class multiplies the quantity of each ingredient by the scaling factor entered by the user.
When the user requests to reset the recipe, the Reset() method in the Recipe class should restore the quantities of the ingredients to their original values. 
The Clear() method in the Recipe class clears the ingredients and steps lists, effectively clearing the recipe.
 
Overall, this solution demonstrates how to use
object-oriented programming concepts to create a Recipe class that can be used
to represent a recipe and manipulate it as per the user's request in a console
application.
 
 

Link to GitHub: https://github.com/Nate1738/NatesApps.git
