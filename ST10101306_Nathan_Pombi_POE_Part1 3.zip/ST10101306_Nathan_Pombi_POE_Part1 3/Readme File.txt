# Time Management Application

This is a standalone desktop time management application written in C# and powered by Windows Presentation Foundation (WPF). It enables users to manage modules for a semester, compute self-study hours, track module hours, and more.



Compile:

First, extract the file from the zip file and save it in your proper c# document file.
\
In the File that is linked to the WPF Application, there is a Project Named Library for the Class Library. Save the file as a C# document.

After you've extracted the file, launch Visual Studio and navigate to the extracted file.



Usage:

Then launch the app:

Modules should be added:

In the supplied textboxes, enter the module information (Code, Name, Credits, Class Hours).
To add the module to the List View, click the "Add Module" button.

then,

Determine The Self-Study Hours:

The number of weeks for each module should be the same. Because all modules are registered on the same day and during the same week. 

In the "Weeks" textbox, enter the number of weeks.
To calculate self-study hours for all modules, click the "Save" button.
Enter a date for this week and press the save button.

Record Hours Worked:

Choose a module from the combobox menu.
Using the date picker, select a date.
In the "Hours Worked" textbox, enter the number of hours worked.
To record the hours worked and update the remaining hours, click the "Record Hours" option.

The remaining hours of self-study per week will be displayed in the list box.

These are the instructions for compiling and running the software.


