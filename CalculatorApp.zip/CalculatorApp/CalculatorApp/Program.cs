﻿namespace CalculatorApp;
class Program
{
    static void Main(string[] args)
    {

        //intializing the variables
        double num1 = 0;
        double num2 = 0;
        double result;
        bool tryAgain = true;


        

        //loop to restart the app if user wish to calculate again
        do
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("---------------");
            Console.WriteLine("Calculator App");
            Console.WriteLine("---------------");
            Console.WriteLine("");

            //loop to restart the entering number sequence
            do
            {

                //an error catcher for if the user enters an invalid selection in the sequence 
                try
                {
                    Console.WriteLine("Enter your first number");
                    num1 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Enter your Second number");
                    num2 = Convert.ToDouble(Console.ReadLine());
                    tryAgain = false;

                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("invalid selection");
                    Console.ForegroundColor = ConsoleColor.White;
                    tryAgain = true;
                }
            } while (tryAgain);



            //displaying the options the options to the user
            Console.WriteLine("");
            Console.WriteLine("Choose a function:");
            Console.WriteLine("\t + : Addition");
            Console.WriteLine("\t - : Subtraction");
            Console.WriteLine("\t * : Multiplication");
            Console.WriteLine("\t / : Division");
            Console.Write("Enter the symbol of your function: ");


            //switch method to choose the functions from the user input and calculate them
            switch (Console.ReadLine())
            {
                case "+":
                    result = num1 + num2;
                    Console.ForegroundColor = ConsoleColor.DarkBlue;
                    Console.WriteLine($"{num1} + {num2} = {result}");
                    break;
                case "-":
                    result = num1 - num2;
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"{num1} - {num2} = {result}");
                    break;
                case "*":
                    result = num1 * num2;
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"{num1} * {num2} = {result}");
                    break;
                case "/":
                    result = num1 / num2;
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine($"{num1} ÷ {num2} = {Math.Round(result,2)}");
                    break;
                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid Symbol");
                    break;

            }
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Do you wish to restart (Y/N)");
            // option to activate the loop that restarts the app
        } while (Console.ReadLine().ToUpper() == "Y");
        

        Console.ReadKey();
    }
}
