﻿namespace RandomNumberGame
{
    class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            //initializing the varaibles for the game
            int guess;
            int min;
            int max;
            bool playAgain = true;
            int number;
            string Response;


            //function to replay the game
            while (playAgain)
            {
                
                guess = 0;
               int guesses = 0;

                //the questions asked on the console
                Console.WriteLine("Enter the min Number for the Game!");
                min = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the max number for the Game!");
                max = Convert.ToInt32(Console.ReadLine());
                number = random.Next(min, max + 1);

                Console.WriteLine("Enter the number you guessing it is?");

                //ensures that if the answer from the user is not correct it loops until the right answer is chosen
                while (guess != number)
                {

                    
                    guess = Convert.ToInt32(Console.ReadLine());

                    //checks if the answer given by the user is correct/too high/too low
                    if (guess > number)
                    {
                        Console.WriteLine("The number you've chosen is a bit too high");
                        Console.WriteLine("Try Again");
                    }
                    else if (guess<number)
                    {
                        Console.WriteLine("The number you've chosen is a bit too low");
                        Console.WriteLine("Try Again");
                    }
                    else
                    {
                        Console.WriteLine("Correct!!!...The answer you have chosen is the correct one" + "\n" + $"attempts: {guesses}");
                    }
                    guesses++;

                   
                }

                //asking the user if they want to play again
                Console.WriteLine("Do you wish to play again?  (Y/N)");
                Response = Console.ReadLine();
                Response = Response.ToUpper();

                //checks the response of the user, if they want to play again or not 
                if (Response == "Y")
                {
                    playAgain = true;
                }
                else
                {
                    playAgain = false;
                }

            }
        }
    }
}