﻿using System;
namespace MultiplayerRockPaperScissors.Multi
{
	public class singleplayer
	{
		public void Run()
		{
            Random random = new Random();
            //initializing the variables 
            bool playAgain = true;
            string userInput;
            string computer;
            int number;
            int won = 0;
            int draw = 0;
            int loss = 0;

            //this allows the game to loop consistantly
            while (playAgain)
            {
                //this resets the variables

                userInput = "";
                computer = "";

                //propmts the questions on console
                Console.WriteLine("enter ROCK/PAPER/SCISSORS!!");
                userInput = Console.ReadLine();
                userInput = userInput.ToUpper();

                //catches all the invalid inputs thats not rock/paper/scissors
                while (userInput != "ROCK" && userInput != "PAPER" && userInput != "SCISSORS")
                {
                    Console.WriteLine("Invalid selection...Choose ROCK, PAPER, SCISSORS");
                    userInput = Console.ReadLine();
                    userInput = userInput.ToUpper();
                }

                //gives the random numbers a value for the game
                switch (random.Next(1, 4))
                {
                    case 1:
                        computer = "ROCK";
                        break;
                    case 2:
                        computer = "PAPER";
                        break;
                    case 3:
                        computer = "SCISSORS";
                        break;

                }

                //displays what the user and opponent chose
                Console.WriteLine($"Player: {userInput}");
                Console.WriteLine($"Computer: {computer}");


                //runs to see who won the round or if the round ended in a draw
                switch (userInput)
                {
                    case "ROCK":
                        if (computer == "ROCK")
                        {
                            Console.WriteLine("You have Reached a stalemate...Draw!");
                            draw++;
                        }
                        else if (computer == "PAPER")
                        {
                            Console.WriteLine("You have lost");
                            loss++;
                        }
                        else
                        {
                            Console.WriteLine("You have won");
                            won++;
                        }
                        break;
                    case "PAPER":
                        if (computer == "ROCK")
                        {
                            Console.WriteLine("You have won");
                            won++;
                        }
                        else if (computer == "PAPER")
                        {
                            Console.WriteLine("You have reached a stalemate...Draw!");
                            draw++;
                        }
                        else
                        {
                            Console.WriteLine("You have lost");
                            loss++;
                        }
                        break;
                    case "SCISSORS":
                        if (computer == "ROCK")
                        {
                            Console.WriteLine("You have lost");
                            loss++;
                        }
                        else if (computer == "PAPER")
                        {
                            Console.WriteLine("You Have Won!!");
                            won++;
                        }
                        else
                        {
                            Console.WriteLine("You have reached a stalemate...Draw!!!");
                            draw++;
                        }
                        break;

                }
                //shows the users record
                Console.WriteLine($"win: {won} Lost: {loss} Draw: {draw}");

            }


        }
    
	}
}

