﻿namespace MultiplayerRockPaperScissors.Multi;

class Program
{
    static void Main(string[] args)
    {
        multiplayer multi = new multiplayer();
        singleplayer single = new singleplayer();


        Console.WriteLine("How many players will be playing..1 or 2");
        int answer = Convert.ToInt32(Console.ReadLine());

        if (answer == 1)
        {
            single.Run();
        }
        else
        {
            multi.Run();
        }
    }
}

