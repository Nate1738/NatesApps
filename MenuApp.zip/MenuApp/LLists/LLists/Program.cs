﻿namespace MenuApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //declaring the bool
            bool again = true;
            //declaring choice for later use
            string choice;

            //useing the bool for the menu loop
            //looping the menu
            while (again)
            {
                //create menu for displaying for the user
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("--------------------------------------");
                Console.WriteLine("\tWelcome!!!!");
                Console.WriteLine("--------------------------------------");
                Console.WriteLine("Players: \nNate\nAmahle\nKeren");
                Console.WriteLine("--------------------------------------");
                Console.WriteLine("Enter the number of the option you wish to perform");
                Console.WriteLine("--------------------------------------");
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("1: Check Weight of a player of your choice");
                Console.WriteLine("2: Check the height of the players");
                Console.WriteLine("3: check who's the heavist between 2 players of your choice");
                Console.WriteLine("4: Who is tallest between 2 players of your choice");
                Console.WriteLine("5: Exit");
                //declaring the bool for later use 
                bool repeat = true;

                //enclosed in a try catch in case the user enters anything other than an integer
                try
                {
                    int choose = Convert.ToInt32(Console.ReadLine());

                    //using switch method for the menu
                    switch (choose)
                    {
                        case 1:

                           //looping user input, loop only ends once the user enters the correct name
                            while (repeat)
                            {
                                Console.ForegroundColor = ConsoleColor.Green;
                                //asking user to enter name
                                Console.WriteLine("Which player do you want to check the weight");
                                string player = Console.ReadLine();
                                player.ToLower();

                                //using if statement to check if the user entered the correct names
                                if (player == "nate")
                                {
                                    //getting the information from the enum and displaying it for user to see
                                    Console.WriteLine((int)weight.Nate + "kg");
                                    repeat =false;
                                }
                                else if (player == "amahle")
                                {
                                    //getting the information from the enum and displaying it for user to see
                                    Console.WriteLine((int)weight.Amahle + "kg");
                                    repeat = false;
                                }
                                else if (player == "keren")
                                {
                                    //getting the information from the enum and displaying it for user to see
                                    Console.WriteLine((int)weight.Keren + "kg");
                                    repeat = false;
                                }
                                else
                                {
                                    Console.WriteLine("Invalid name...enter the names you've been given");


                                }
                            }
                            
                            Console.ReadKey();
                            Console.Clear();
                            break;
                        case 2:


                            //looping user input, loop only ends once the user enters the correct name

                            while (repeat)
                            {
                                //asking user to enter name

                                Console.ForegroundColor = ConsoleColor.DarkBlue;
                                Console.WriteLine("Who's height do you wish to check?");
                                string name = Console.ReadLine();
                                name.ToLower();

                                //using if statement to check if the user entered the correct names
                                if (name == "nate")
                                {
                                    //getting the information from the enum and displaying it for user to see
                                    Console.WriteLine((int)height.Nate + "cm");
                                    repeat = false;
                                }
                                else if (name == "amahle")
                                {
                                    //getting the information from the enum and displaying it for user to see
                                    Console.WriteLine((int)height.Amahle + "cm");
                                    repeat = false;
                                }
                                else if (name == "keren")
                                {
                                    //getting the information from the enum and displaying it for user to see
                                    Console.WriteLine((int)height.Keren+ "cm");
                                    repeat = false;
                                }
                                else
                                {
                                    Console.WriteLine("invalid name...enter the names you've been given");
                                   
                                }
                            }
                            
                            Console.ReadKey();
                            Console.Clear();
                            break;
                        case 3:

                            //looping user input, loop only ends once the user enters the correct name
                            while (repeat)
                            {
                                //asking user to enter name
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                Console.WriteLine("name the first player you choosing");
                                string p1 = Console.ReadLine();
                                p1.ToLower();

                                //asking user to enter name
                                Console.WriteLine("name the second player you choosing");
                                string p2 = Console.ReadLine();
                                p2.ToLower();

                                //using if statement to check if the user entered the correct names
                                if (p1 == "nate" && p2 == "amahle")
                                {
                                    //getting the information from the enum 
                                    int m = Math.Max((int)weight.Nate, (int)weight.Amahle);

                                    //using another if statement to check the weight and see who's heavier
                                    if (m == 88)
                                    {
                                        Console.WriteLine("Nate is heavier");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Amahle is heavier");
                                    }
                                    repeat = false;
                                }
                                //using if statement to check if the user entered the correct names
                                else if (p1 == "amahle" && p2 == "nate")
                                {
                                    //getting the information from the enum 
                                    int m = Math.Max((int)weight.Nate, (int)weight.Amahle);

                                    //using another if statement to check the weight and see who's heavier
                                    if (m == 88)
                                    {
                                        Console.WriteLine("Nate is heavier");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Amahle is heavier");
                                    }
                                    repeat = false;
                                }
                                //using if statement to check if the user entered the correct names
                                else if (p1 == "amahle" && p2 == "keren")
                                {
                                    //getting the information from the enum 
                                    int m = Math.Max((int)weight.Amahle, (int)weight.Keren);

                                    //using another if statement to check the weight and see who's heavier
                                    if (m == 70)
                                    {
                                        Console.WriteLine("keren is heavier");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Amahle is heavier");
                                    }
                                    repeat = false;
                                }
                                //using if statement to check if the user entered the correct names
                                else if (p1 == "keren" && p2 == "amahle")
                                {
                                    //getting the information from the enum 
                                    int m = Math.Max((int)weight.Amahle, (int)weight.Keren);

                                    //using another if statement to check the weight and see who's heavier
                                    if (m == 70)
                                    {
                                        Console.WriteLine("keren is heavier");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Amahle is heavier");
                                    }
                                    repeat = false;
                                }
                                //using if statement to check if the user entered the correct names
                                else if (p1 == "keren" && p2 == "nate")
                                {
                                    //getting the information from the enum 
                                    int m = Math.Max((int)weight.Nate, (int)weight.Keren);

                                    //using another if statement to check the weight and see who's heavier
                                    if (m == 88)
                                    {
                                        Console.WriteLine("Nate is heavier");
                                    }
                                    else
                                    {
                                        Console.WriteLine("keren is heavier");
                                    }
                                    repeat = false;
                                }
                                //using if statement to check if the user entered the correct names
                                else if (p1 == "nate" && p2 == "keren")
                                {
                                    //getting the information from the enum 
                                    int m = Math.Max((int)weight.Nate, (int)weight.Keren);

                                    //using another if statement to check the weight and see who's heavier
                                    if (m == 88)
                                    {
                                        Console.WriteLine("Nate is heavier");
                                    }
                                    else
                                    {
                                        Console.WriteLine("keren is heavier");
                                    }
                                    repeat = false;
                                }
                                else
                                {
                                    Console.WriteLine("invalid names...enter the names you've been given");

                                }
                            }
                            Console.ReadKey();
                            Console.Clear();
                            break;

                        case 4:
                            //looping user input, loop only ends once the user enters the correct name
                            while (repeat)
                            {
                                //asking user to enter name
                                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                                Console.WriteLine("name the first player you choosing");
                                string c1 = Console.ReadLine();
                                c1.ToLower();

                                //asking user to enter name
                                Console.WriteLine("name the second player you choosing");
                                string c2 = Console.ReadLine();
                                c2.ToLower();

                                //using if statement to check if the user entered the correct names
                                if (c1 == "nate" && c2 == "amahle")
                                {

                                    //getting the information from the enum
                                    int m = Math.Max((int)height.Nate, (int)height.Amahle);

                                    //using another if statement to check the height and see who's taller
                                    if (m == 179)
                                    {
                                        Console.WriteLine("Nate is Taller");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Amahle is Taller");
                                    }
                                    repeat = false;
                                }

                                //using if statement to check if the user entered the correct names
                                else if (c1 == "amahle" && c2 == "nate")
                                {
                                    //getting the information from the enum
                                    int m = Math.Max((int)height.Nate, (int)height.Amahle);

                                    //using another if statement to check the height and see who's taller
                                    if (m == 179)
                                    {
                                        Console.WriteLine("Nate is taller");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Amahle is taller");
                                    }
                                    repeat = false;
                                }

                                //using if statement to check if the user entered the correct names
                                else if (c1 == "amahle" && c2 == "keren")
                                {
                                    //getting the information from the enum
                                    int m = Math.Max((int)height.Amahle, (int)height.Keren);

                                    //using another if statement to check the height and see who's taller
                                    if (m == 156)
                                    {
                                        Console.WriteLine("keren is taller");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Amahle is taller");
                                    }
                                    repeat = false;
                                }

                                //using if statement to check if the user entered the correct names
                                else if (c1 == "keren" && c2 == "amahle")
                                {
                                    //getting the information from the enum
                                    int m = Math.Max((int)height.Amahle, (int)height.Keren);

                                    //using another if statement to check the height and see who's taller
                                    if (m == 156)
                                    {
                                        Console.WriteLine("keren is taller");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Amahle is taller");
                                    }
                                    repeat = false;
                                }

                                //using if statement to check if the user entered the correct names
                                else if (c1 == "keren" && c2 == "nate")
                                {
                                    //getting the information from the enum
                                    int m = Math.Max((int)height.Nate, (int)height.Keren);

                                    //using another if statement to check the height and see who's taller
                                    if (m == 179)
                                    {
                                        Console.WriteLine("Nate is taller");
                                    }
                                    else
                                    {
                                        Console.WriteLine("keren is taller");
                                    }
                                    repeat = false;
                                }

                                //using if statement to check if the user entered the correct names
                                else if (c1 == "nate" && c2 == "keren")
                                {
                                    //getting the information from the enum
                                    int m = Math.Max((int)height.Nate, (int)height.Keren);

                                    //using another if statement to check the height and see who's taller
                                    if (m == 179)
                                    {
                                        Console.WriteLine("Nate is taller");
                                    }
                                    else
                                    {
                                        Console.WriteLine("keren is taller");
                                    }
                                    repeat = false;
                                }

                                else
                                {
                                    Console.WriteLine("invalid names...enter the names you've been given");
                                }
                            }
                            Console.ReadKey();
                            Console.Clear();
                            break;
                        case 5:
                            again = false;
                            break;
                        default:
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Invalid selection please selected from the options given to you");
                            return;
                            
                    }
                   

                }
                //catches format exception
                catch (FormatException ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine();
                    Console.WriteLine("Please enter the number of the option you choose to exercute!!!");

                    Console.ReadKey();
                    Console.Clear();
                }

                
            }
     
        }
        
    }

    enum weight
    {
        Nate = 88,
        Amahle = 68,
        Keren = 70,

    }

    enum height
    {
        Nate = 179,
        Amahle = 148,
        Keren = 156,
    }

   
}