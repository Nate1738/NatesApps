﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection.Metadata;
using System.Xml.Linq;
using Part2_.Method;

using System;
using System.Collections.Generic;

namespace RecipeManager
{
    
    class Program
    {
        /*The Run method starts the user interface loop, displaying a menu of options and executing the selected option.*/
        static void Main(string[] args)
        {
            Methods.UserInt meth = new Methods.UserInt();
            meth.Run();



        }
    }
}