Time management App

This WPF c# application allows you to record semesters, calculate selfstudy hours, add modules.
It is an upgrade to the first application i made prior In this upgraded version it incorporates database.The upgrade allows you to now register into the app with your personal information as well as use that information to log into the app; these personal information you've entered will be saved into the database which is how you are able to log in with those details you've entered. Once logging into the app you can enter your course information. once you enter your course information that details will be immediately stored into the database.


***You need extract the zip file first***
 
-After the zip file is extracted, 

You will find the:
Class library folder
App code folder
Database folder

-Please open the app code with visual studio

-Once you have extracted the file, open your Visual Studio, and open the extracted file.

-The WPF application consists of three projects:
PoeLibriary 
Poepart1
database
 

Usage:

1.Run the App then:

2. The app will open onto a log in page, if you are not registered yet click the sign up button on your left hand side.

3.Register your account using name, surname, username, email and password.

4.Click on register once done the app will show you Your username and then your student id which you should not forget because it is needed for your Courses.

5. once the Log in Page pops up login using your username and password.

6.Add Modules:

Fill in the module information (Code, Name, Credits, Class Hours) in the provided textboxes.
Click the "Add" button to add the module to the List View. by clicking add you are also saving the data into the database Course Table

then,

7.Calculate The Self-Study Hours:

The number of weeks should be the same number for all modules. Because all modules are registered the the day and same week. 

8.Enter the number of weeks in the "Weeks" textbox.
9.Click the "Display" button to calculate self-study hours for all modules.
10.Enter a date for the current week and click the record button.

11.Record Hours Worked:

12.Select a module from the dropdown list.
13.Pick a date using the date picker.
14.Enter the hours worked in the "Class Hours" textbox.
15.Click the "Record" button to record the hours worked and update the remaining hours.

16.The list box will display the remaining hours of self-study per week.

These are the instructions for how to compile and run the software.


P.S

if the Database connection fails to open and you get a Microsoft.Data.SqlException: an attempt to attach  an auto-named database for file.........etc

1. go to the serve explorer tab
2. right click on database.mdf
3. go to properties
4. check the connection string it should match the codes
5. if it does not match copy and paste the new string in the code where it should be



